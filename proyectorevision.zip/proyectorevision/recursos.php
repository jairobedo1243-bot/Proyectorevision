<?php
session_start();
require "db.php";
require "lang.php";

$PERMISOS = [
    "administrador" => [
        "etiqueta" => tv("Administrador"),
        "clase"    => "badge-danger",
        "paginas"  => ["index.php", "recursos.php", "usuarios.php", "prestamos.php", "tickets.php", "reportes.php", "historial.php"],
        "inventarioEditar" => true, "usuariosAdministrar" => true, "ticketsCerrar" => true
    ],
    "tecnico" => [
        "etiqueta" => tv("Tecnico"),
        "clase"    => "badge-warning",
        "paginas"  => ["index.php", "recursos.php", "prestamos.php", "tickets.php", "reportes.php", "historial.php"],
        "inventarioEditar" => false, "usuariosAdministrar" => false, "ticketsCerrar" => true
    ],
    "solicitante" => [
        "etiqueta" => tv("Solicitante"),
        "clase"    => "badge-info",
        "paginas"  => ["index.php", "prestamos.php", "tickets.php"],
        "inventarioEditar" => false, "usuariosAdministrar" => false, "ticketsCerrar" => false
    ]
];

function normalizarRol($rol) {
    $r = mb_strtolower(trim($rol));
    if (strpos($r, "admin") !== false) return "administrador";
    if (strpos($r, "tecnico") !== false || strpos($r, "técnico") !== false) return "tecnico";
    return "solicitante";
}

if (!isset($_SESSION["usuario"])) {
    header("Location: login.php");
    exit;
}
$usuario = $_SESSION["usuario"];
$permiso = $PERMISOS[normalizarRol($usuario["rol"])];
if (!in_array("recursos.php", $permiso["paginas"])) {
    header("Location: index.php");
    exit;
}

$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] === "POST" && $permiso["inventarioEditar"]) {
    $numeroSerie = trim($_POST["numeroSerie"]);
    $modelo      = trim($_POST["modelo"]);
    $marca       = trim($_POST["marca"]);
    $tipo        = $_POST["tipo"];

    $conn->execute_query("INSERT INTO equipo (estado, numeroSerie, modelo, marca, tipo)
                          VALUES ('Disponible', '$numeroSerie', '$modelo', '$marca', '$tipo')");

    $mensaje = t("msgEquipoAgregado") . $modelo;
}

$resultado = $conn->execute_query("SELECT * FROM equipo ORDER BY id_equipo DESC");
?>
<!DOCTYPE html>
<html lang="<?= $idioma ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= t("tituloInventario") ?></title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<header>
    <h1>SGRSI</h1>
    <p><?= t("appSubtitulo") ?></p>
    <div style="margin-top:8px;font-size:0.85rem;opacity:0.9;">
        <?= $usuario["nom"] ?> <?= $usuario["ape"] ?>
        <span class="badge <?= $permiso["clase"] ?>" style="vertical-align:middle;margin-left:4px;"><?= $permiso["etiqueta"] ?></span>
    </div>
    <div style="margin-top:6px;font-size:0.8rem;">
        <a href="?idioma=es" style="color:<?= $idioma === "es" ? "#fff" : "#94a3b8" ?>;text-decoration:none;font-weight:<?= $idioma === "es" ? "700" : "400" ?>;">ES</a>
        <span style="opacity:0.5;">|</span>
        <a href="?idioma=en" style="color:<?= $idioma === "en" ? "#fff" : "#94a3b8" ?>;text-decoration:none;font-weight:<?= $idioma === "en" ? "700" : "400" ?>;">EN</a>
    </div>
</header>

<nav>
    <a href="index.php"><?= t("navInicio") ?></a>
    <a href="recursos.php" class="activo"><?= t("navInventario") ?></a>
    <?php if (in_array("usuarios.php", $permiso["paginas"])): ?><a href="usuarios.php"><?= t("navUsuarios") ?></a><?php endif; ?>
    <?php if (in_array("prestamos.php", $permiso["paginas"])): ?><a href="prestamos.php"><?= t("navPrestamos") ?></a><?php endif; ?>
    <?php if (in_array("tickets.php", $permiso["paginas"])): ?><a href="tickets.php"><?= t("navTickets") ?></a><?php endif; ?>
    <?php if (in_array("reportes.php", $permiso["paginas"])): ?><a href="reportes.php"><?= t("navReportes") ?></a><?php endif; ?>
    <?php if (in_array("historial.php", $permiso["paginas"])): ?><a href="historial.php"><?= t("navHistorial") ?></a><?php endif; ?>

    <a href="logout.php" style="margin-left:auto;color:#fca5a5;"><?= t("navCerrarSesion") ?></a>
</nav>

<main>
    <section id="registroEquipo">
        <h2><?= t("registroEquiposTitulo") ?></h2>

        <?php if ($permiso["inventarioEditar"]): ?>
            <form method="POST">
                <label for="modeloEquipo"><?= t("labelModelo") ?></label>
                <input type="text" id="modeloEquipo" name="modelo" placeholder="<?= t("placeholderModelo") ?>" required>

                <label for="marcaEquipo"><?= t("labelMarca") ?></label>
                <input type="text" id="marcaEquipo" name="marca" placeholder="<?= t("placeholderMarca") ?>" required>

                <label for="numeroSerieEquipo"><?= t("labelNumeroSerie") ?></label>
                <input type="text" id="numeroSerieEquipo" name="numeroSerie" placeholder="<?= t("placeholderNumeroSerie") ?>" required>

                <label for="tipoEquipo"><?= t("labelTipoEquipo") ?></label>
                <select id="tipoEquipo" name="tipo" required>
                    <option value=""><?= t("opcionSeleccionar") ?></option>
                    <option value="PC"><?= tv("PC") ?></option>
                    <option value="Laptop"><?= tv("Laptop") ?></option>
                    <option value="Monitor"><?= tv("Monitor") ?></option>
                    <option value="Proyector"><?= tv("Proyector") ?></option>
                    <option value="Television"><?= tv("Television") ?></option>
                    <option value="Otro"><?= tv("Otro") ?></option>
                </select>

                <button type="submit"><?= t("botonAgregarEquipo") ?></button>
            </form>
        <?php else: ?>
            <p class="mensaje info"><?= t("avisoSoloConsultaInventario") ?></p>
        <?php endif; ?>

        <?php if ($mensaje !== ""): ?><p class="mensaje"><?= $mensaje ?></p><?php endif; ?>

        <div class="tabla-wrapper">
            <table>
                <thead>
                    <tr><th><?= t("thNum") ?></th><th><?= t("thModelo") ?></th><th><?= t("thMarca") ?></th><th><?= t("thNSerie") ?></th><th><?= t("thTipo") ?></th><th><?= t("thEstado") ?></th></tr>
                </thead>
                <tbody>
                    <?php $i = 0; foreach ($resultado as $fila): $i++;
                        $badgeClase = $fila["estado"] === "Disponible" ? "badge-success"
                                    : ($fila["estado"] === "Prestado" ? "badge-warning" : "badge-danger");
                    ?>
                        <tr>
                            <td><?= $i ?></td>
                            <td><?= $fila["modelo"] ?></td>
                            <td><?= $fila["marca"] ?></td>
                            <td><?= $fila["numeroSerie"] ?></td>
                            <td><?= tv($fila["tipo"]) ?></td>
                            <td><span class="badge <?= $badgeClase ?>"><?= tv($fila["estado"]) ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
</main>

<footer>
    <p><?= t("footer") ?></p>
</footer>

</body>
</html>
